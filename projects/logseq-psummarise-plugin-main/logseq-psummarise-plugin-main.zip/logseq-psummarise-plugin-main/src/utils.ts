import { BlockEntity, IBatchBlock } from '@logseq/libs/dist/LSPlugin.user'

import { createSecondCutBtn } from './createSecondCutBtn'
import { recurseFirstCut } from './recursiveHighlights'

const uniqueIdentifier = () =>
  Math.random()
    .toString(36)
    .replace(/[^a-z]+/g, '')

// 查找现有的 Layer 1 块
const findExistingLayer1Block = async (): Promise<BlockEntity | null> => {
  try {
    const pageBT = await logseq.Editor.getCurrentPageBlocksTree()
    if (!pageBT) return null

    // 递归查找包含 Layer 1 标识的块
    const findLayer1InBlocks = (blocks: BlockEntity[]): BlockEntity | null => {
      for (const block of blocks) {
        if (block.content && block.content.includes(String(logseq.settings!.layer1)) && 
            block.content.includes('{{renderer :secondCut_')) {
          return block
        }
        if (block.children && block.children.length > 0) {
          const found = findLayer1InBlocks(block.children as BlockEntity[])
          if (found) return found
        }
      }
      return null
    }

    return findLayer1InBlocks(pageBT)
  } catch (error) {
    console.error('Error finding existing Layer 1 block:', error)
    return null
  }
}

// 标准化文本用于比较，移除用户添加的高亮标记
const normalizeTextForComparison = (text: string): string => {
  // 移除 Markdown 高亮标记 ==text==
  let normalized = text.replace(/==(.*?)==/g, '$1')
  // 移除 Org 高亮标记 ^^text^^
  normalized = normalized.replace(/\^\^(.*?)\^\^/g, '$1')
  // 移除 Markdown 粗体标记 **text**
  normalized = normalized.replace(/\*\*(.*?)\*\*/g, '$1')
  // 移除 Org 粗体标记 *text*
  normalized = normalized.replace(/\*(.*?)\*/g, '$1')
  
  return normalized.trim()
}

// 解析现有块的内容，提取高亮项目
const parseExistingHighlights = (children: BlockEntity[]): Map<string, { block: BlockEntity, sourceId: string, normalizedText: string }> => {
  const existingMap = new Map<string, { block: BlockEntity, sourceId: string, normalizedText: string }>()
  
  console.log('Plugin Debug - Parsing existing highlights from', children.length, 'children')
  
  for (const child of children) {
    if (child.content) {
      console.log('Plugin Debug - Parsing child content:', JSON.stringify(child.content))
      
      // 查找 [xxx](yyy) 模式，但不要求在末尾（因为后面可能有 \nid:: ...）
      const linkMatch = child.content.match(/\[([^\]]*)\]\(([^)]+)\)/)
      
      if (linkMatch && linkMatch[2]) {
        // 提取链接前的所有内容作为高亮文本
        const linkStart = child.content.indexOf('[')
        const highlightText = child.content.substring(0, linkStart).trim()
        const sourceId = linkMatch[2]
        
        if (highlightText) {
          const normalizedText = normalizeTextForComparison(highlightText)
          existingMap.set(normalizedText, { block: child, sourceId, normalizedText })
          console.log('Plugin Debug - Found existing highlight:', JSON.stringify(highlightText))
          console.log('Plugin Debug - Normalized for comparison:', JSON.stringify(normalizedText), 'from source:', sourceId)
        } else {
          console.log('Plugin Debug - Empty highlight text for:', JSON.stringify(child.content))
        }
      } else {
        console.log('Plugin Debug - No link pattern found in:', JSON.stringify(child.content))
      }
    } else {
      console.log('Plugin Debug - Child has no content:', child.uuid)
    }
  }
  
  console.log('Plugin Debug - Total existing highlights parsed:', existingMap.size)
  return existingMap
}

// 增量更新 Layer 1 块的子块
const incrementalUpdateLayer1Children = async (
  layerOneBlock: BlockEntity, 
  newHighlights: { highlights: string[]; id: string }[]
): Promise<void> => {
  try {
    console.log('Plugin Debug - Getting Layer 1 block with children:', layerOneBlock.uuid)
    const blockWithChildren = await logseq.Editor.getBlock(layerOneBlock.uuid, {
      includeChildren: true,
    })
    
    console.log('Plugin Debug - Children count:', blockWithChildren?.children?.length || 0)
    
    const existingChildren = (blockWithChildren?.children as BlockEntity[]) || []
    const existingMap = parseExistingHighlights(existingChildren)
    
    // 创建新高亮的映射（使用标准化文本作为键）
    const newHighlightMap = new Map<string, string>()
    for (const h of newHighlights) {
      for (const highlight of h.highlights) {
        const normalizedHighlight = normalizeTextForComparison(highlight)
        newHighlightMap.set(normalizedHighlight, h.id)
      }
    }
    
    console.log('Plugin Debug - New highlights count:', newHighlightMap.size)
    console.log('Plugin Debug - Existing highlights count:', existingMap.size)
    
    // 打印新高亮内容
    for (const [normalizedText, id] of newHighlightMap) {
      console.log('Plugin Debug - New highlight (normalized):', normalizedText, 'from:', id)
    }
    
    // 打印现有高亮内容
    for (const [normalizedText, {sourceId}] of existingMap) {
      console.log('Plugin Debug - Existing highlight (normalized):', normalizedText, 'from:', sourceId)
    }
    
    // 找出需要删除的块（在现有中但不在新的中）
    const toDelete: BlockEntity[] = []
    const toKeep: string[] = []
    
    for (const [normalizedText, { block }] of existingMap) {
      if (!newHighlightMap.has(normalizedText)) {
        toDelete.push(block)
        console.log('Plugin Debug - Will delete:', normalizedText, '(not in new highlights)')
      } else {
        toKeep.push(normalizedText)
        console.log('Plugin Debug - Will keep unchanged:', normalizedText, '(preserving user highlights)')
        console.log('Plugin Debug - Kept block content before:', JSON.stringify(block.content))
      }
    }
    
    // 删除不再需要的块
    for (const block of toDelete) {
      await logseq.Editor.removeBlock(block.uuid)
      console.log('Plugin Debug - Removed outdated highlight:', block.content)
    }
    
    // 只添加真正新的高亮（在新的中但不在现有中）
    const newBlocks: IBatchBlock[] = []
    // 需要从原始的 newHighlights 中找到对应的原始文本
    for (const h of newHighlights) {
      for (const originalHighlight of h.highlights) {
        const normalizedHighlight = normalizeTextForComparison(originalHighlight)
        if (!existingMap.has(normalizedHighlight)) {
          newBlocks.push({
            content: `${originalHighlight} [${logseq.settings!.highlightsRefChar}](${h.id})`
          })
          console.log('Plugin Debug - Will add:', originalHighlight, '(new highlight)')
        }
      }
    }
    
    // 批量插入新块
    if (newBlocks.length > 0) {
      await logseq.Editor.insertBatchBlock(
        layerOneBlock.uuid,
        newBlocks,
        {
          before: false,
          sibling: false,
        }
      )
      console.log('Plugin Debug - Added new highlights:', newBlocks.length)
    }
    
    console.log('Plugin Debug - Incremental update completed. Deleted:', toDelete.length, 'Added:', newBlocks.length)
    
    // 验证保留的块是否真的被保留了
    if (toKeep.length > 0) {
      console.log('Plugin Debug - Verifying preserved blocks...')
      const updatedBlockWithChildren = await logseq.Editor.getBlock(layerOneBlock.uuid, {
        includeChildren: true,
      })
      
      if (updatedBlockWithChildren?.children) {
        for (const child of updatedBlockWithChildren.children as BlockEntity[]) {
          const linkMatch = child.content?.match(/\[([^\]]*)\]\(([^)]+)\)/)
          if (linkMatch) {
            const linkStart = child.content!.indexOf('[')
            const highlightText = child.content!.substring(0, linkStart).trim()
            const normalizedText = normalizeTextForComparison(highlightText)
            if (toKeep.includes(normalizedText)) {
              console.log('Plugin Debug - Preserved block content after:', JSON.stringify(child.content))
            }
          }
        }
      }
    }
  } catch (error) {
    console.error('Error in incremental update Layer 1 children:', error)
  }
}

export const goSummarise = async (arrOfBlocks: BlockEntity[]) => {
  ///////////////////
  //// FIRST CUT ////
  ///////////////////
  // Get matches
  const firstCutArr: { highlights: string[]; id: string }[] = []

  await recurseFirstCut(arrOfBlocks, firstCutArr)

  // Filter out empty highlight arrays
  const validHighlights = firstCutArr.filter(item => item.highlights && item.highlights.length > 0)

  console.log('Plugin Debug - Total blocks processed:', firstCutArr.length)
  console.log('Plugin Debug - Valid highlights found:', validHighlights.length)
  console.log('Plugin Debug - Settings:', logseq.settings)

  if (validHighlights.length === 0) {
    const { preferredFormat } = await logseq.App.getUserConfigs()
    logseq.UI.showMsg(
      `No highlights found. 请确保您有高亮内容，并检查插件设置是否符合您的工作流程。当前格式: ${preferredFormat}, Layer 1 方法: ${logseq.settings!.layer1Highlights}`,
      'error',
    )
    return
  }

  // 查找现有的 Layer 1 块或创建新的
  if (!arrOfBlocks[0]) return
  
  let layerOneBlock = await findExistingLayer1Block()
  
  if (layerOneBlock) {
    // 如果找到现有的 Layer 1 块，进行增量更新
    console.log('Plugin Debug - Found existing Layer 1 block, performing incremental update...')
    
    // 检查是否需要更新块标题（只有当 secondCut ID 不存在时才更新）
    const existingContent = layerOneBlock.content || ''
    const secondCutMatch = existingContent.match(/{{renderer :secondCut_([^}]+)}}/)
    const needsHeaderUpdate = !secondCutMatch
    
    if (needsHeaderUpdate) {
      console.log('Plugin Debug - Block header needs update (missing secondCut renderer)')
      const newSecondCutId = uniqueIdentifier()
      console.log('Plugin Debug - Generating new secondCut ID:', newSecondCutId)
      
      await logseq.Editor.updateBlock(
        layerOneBlock.uuid,
        `${String(logseq.settings!.layer1)} {{renderer :secondCut_${newSecondCutId}}}`
      )
      
      // 重新获取更新后的块信息
      const updatedLayerOneBlock = await logseq.Editor.getBlock(layerOneBlock.uuid)
      if (updatedLayerOneBlock) {
        layerOneBlock = updatedLayerOneBlock
      }
    } else {
      console.log('Plugin Debug - Block header is fine, skipping header update to preserve child blocks')
    }
    
    // 进行增量更新子块
    await incrementalUpdateLayer1Children(layerOneBlock, validHighlights)
  } else {
    // 如果没有找到现有的 Layer 1 块，创建新的
    console.log('Plugin Debug - No existing Layer 1 block found, creating new one...')
    layerOneBlock = await logseq.Editor.insertBlock(
      arrOfBlocks[0].uuid,
      `${String(logseq.settings!.layer1)} {{renderer :secondCut_${uniqueIdentifier()}}}`,
      {
        before:
          arrOfBlocks[0].content.includes(':: ') &&
          !arrOfBlocks[0].content.includes('id:: ')
            ? false
            : true,
        sibling: true,
      },
    )
    
    if (!layerOneBlock) return
    
    // 创建初始的子块
    const highlightsBatchBlks: IBatchBlock[] = []
    for (const h of validHighlights) {
      if (h.highlights.length === 1) {
        const payload = {
          content: `${h.highlights[0]} [${logseq.settings!.highlightsRefChar}](${h.id})`,
        }
        highlightsBatchBlks.push(payload)
      } else {
        for (const i of h.highlights) {
          const payload = {
            content: `${i} [${logseq.settings!.highlightsRefChar}](${h.id})`,
          }
          highlightsBatchBlks.push(payload)
        }
      }
    }

    await logseq.Editor.insertBatchBlock(
      layerOneBlock.uuid,
      highlightsBatchBlks,
      {
        before: false,
        sibling: false,
      },
    )
  }

  // Create extract highlights button and implement hack to render it
  if (!layerOneBlock) return
  createSecondCutBtn()
  await logseq.Editor.editBlock(layerOneBlock.uuid, { pos: 1 })
  await logseq.Editor.exitEditingMode()

  // Open summary block in right sidebar
  logseq.Editor.openInRightSidebar(layerOneBlock.uuid)
}
