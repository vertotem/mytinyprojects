// 改进的正则表达式，支持更多格式并更兼容
export const rxMdBoldRef = new RegExp(`\\*\\*([^*]+?)\\*\\*`, `g`)

export const rxOrgBoldRef = new RegExp(`\\*([^*]+?)\\*`, `g`)

export const rxMdHighlightRef = new RegExp(`==([^=]+?)==`, `g`)

export const rxOrgHighlightRef = new RegExp(`\\^\\^([^^]+?)\\^\\^`, `g`)
