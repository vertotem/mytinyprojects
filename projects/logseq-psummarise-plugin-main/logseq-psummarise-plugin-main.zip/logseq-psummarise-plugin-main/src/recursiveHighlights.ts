import '@logseq/libs'

import { BlockEntity } from '@logseq/libs/dist/LSPlugin.user'

import {
  rxMdBoldRef,
  rxMdHighlightRef,
  rxOrgBoldRef,
  rxOrgHighlightRef,
} from './constants'

const findBold = (content: string, preferredFormat: 'markdown' | 'org'): string[] => {
  const rxBlockRef = preferredFormat === 'markdown' ? rxMdBoldRef : rxOrgBoldRef
  const matches: string[] = []
  let match: RegExpExecArray | null
  rxBlockRef.lastIndex = 0 // 重置正则表达式的lastIndex
  while ((match = rxBlockRef.exec(content)) !== null) {
    if (match[1]) {
      matches.push(match[1]) // 提取捕获组内容
    }
  }
  return matches
}

const findHighlights = (
  content: string,
  preferredFormat: 'markdown' | 'org',
): string[] => {
  const rxBlockRef =
    preferredFormat === 'markdown' ? rxMdHighlightRef : rxOrgHighlightRef
  const matches: string[] = []
  let match: RegExpExecArray | null
  rxBlockRef.lastIndex = 0 // 重置正则表达式的lastIndex
  while ((match = rxBlockRef.exec(content)) !== null) {
    if (match[1]) {
      matches.push(match[1]) // 提取捕获组内容
    }
  }
  return matches
}

// first cut is bold
// second cut is highlights

export const recurseFirstCut = async (
  arr: BlockEntity[],
  highlightsArr: { highlights: string[]; id: string }[],
) => {
  const { preferredFormat } = await logseq.App.getUserConfigs()

  console.log('Plugin Debug - Processing blocks, preferredFormat:', preferredFormat)
  console.log('Plugin Debug - Layer1Highlights setting:', logseq.settings!.layer1Highlights)

  for (const b of arr) {
    if (!b.content) {
      console.log('Plugin Debug - Block has no content:', b.uuid)
      continue
    }

    console.log('Plugin Debug - Processing block content:', b.content)

    const highlights =
      logseq.settings!.layer1Highlights === '**Bold**'
        ? findBold(b.content, preferredFormat)
        : findHighlights(b.content, preferredFormat)

    console.log('Plugin Debug - Found highlights:', highlights)

    const payload = {
      highlights,
      id: b.uuid,
    }
    highlightsArr.push(payload)

    if (!b.properties?.id) {
      await logseq.Editor.upsertBlockProperty(b.uuid, 'id', b.uuid)
    }

    if (b.children && b.children.length > 0) {
      await recurseFirstCut(b.children as BlockEntity[], highlightsArr)
    }
  }
}

export const recurseSecondCut = async (
  arr: BlockEntity[],
  highlightsArr: { highlights: string[]; id: string }[],
) => {
  const { preferredFormat } = await logseq.App.getUserConfigs()

  for (const b of arr) {
    if (!b.content) {
      continue
    }

    const highlights =
      logseq.settings!.layer2Highlights === '**Bold**'
        ? findBold(b.content, preferredFormat)
        : findHighlights(b.content, preferredFormat)

    const payload = {
      highlights,
      id: b.uuid,
    }

    highlightsArr.push(payload)

    if (!b.properties?.id) {
      await logseq.Editor.upsertBlockProperty(b.uuid, 'id', b.uuid)
    }

    if (b.children && b.children.length > 0) {
      await recurseSecondCut(b.children as BlockEntity[], highlightsArr)
    }
  }
}
