import '@logseq/libs'

import { BlockEntity, IBatchBlock } from '@logseq/libs/dist/LSPlugin.user'

import { recurseSecondCut } from './recursiveHighlights'

// 查找现有的 Layer 2 块
const findExistingLayer2Block = async (): Promise<BlockEntity | null> => {
  try {
    const pageBT = await logseq.Editor.getCurrentPageBlocksTree()
    if (!pageBT) return null

    // 递归查找包含 Layer 2 标识的块
    const findLayer2InBlocks = (blocks: BlockEntity[]): BlockEntity | null => {
      for (const block of blocks) {
        if (block.content && block.content.includes(String(logseq.settings!.layer2)) && 
            !block.content.includes('{{renderer :secondCut_')) {
          return block
        }
        if (block.children && block.children.length > 0) {
          const found = findLayer2InBlocks(block.children as BlockEntity[])
          if (found) return found
        }
      }
      return null
    }

    return findLayer2InBlocks(pageBT)
  } catch (error) {
    console.error('Error finding existing Layer 2 block:', error)
    return null
  }
}

// 解析现有块的内容，提取高亮项目（与Layer 1相同的逻辑）
const parseExistingHighlights = (children: BlockEntity[]): Map<string, { block: BlockEntity, sourceId: string }> => {
  const existingMap = new Map<string, { block: BlockEntity, sourceId: string }>()
  
  console.log('Plugin Debug - Layer 2: Parsing existing highlights from', children.length, 'children')
  
  for (const child of children) {
    if (child.content) {
      console.log('Plugin Debug - Layer 2: Parsing child content:', JSON.stringify(child.content))
      
      // 查找 [xxx](yyy) 模式，但不要求在末尾（因为后面可能有 \nid:: ...）
      const linkMatch = child.content.match(/\[([^\]]*)\]\(([^)]+)\)/)
      
      if (linkMatch && linkMatch[2]) {
        // 提取链接前的所有内容作为高亮文本
        const linkStart = child.content.indexOf('[')
        const highlightText = child.content.substring(0, linkStart).trim()
        const sourceId = linkMatch[2]
        
        if (highlightText) {
          existingMap.set(highlightText, { block: child, sourceId })
          console.log('Plugin Debug - Layer 2: Found existing highlight:', JSON.stringify(highlightText), 'from source:', sourceId)
        } else {
          console.log('Plugin Debug - Layer 2: Empty highlight text for:', JSON.stringify(child.content))
        }
      } else {
        console.log('Plugin Debug - Layer 2: No link pattern found in:', JSON.stringify(child.content))
      }
    } else {
      console.log('Plugin Debug - Layer 2: Child has no content:', child.uuid)
    }
  }
  
  console.log('Plugin Debug - Layer 2: Total existing highlights parsed:', existingMap.size)
  
  return existingMap
}

// 增量更新 Layer 2 块的子块
const incrementalUpdateLayer2Children = async (
  layerTwoBlock: BlockEntity, 
  newHighlights: { highlights: string[]; id: string }[]
): Promise<void> => {
  try {
    const blockWithChildren = await logseq.Editor.getBlock(layerTwoBlock.uuid, {
      includeChildren: true,
    })
    
    const existingChildren = (blockWithChildren?.children as BlockEntity[]) || []
    const existingMap = parseExistingHighlights(existingChildren)
    
    // 创建新高亮的映射
    const newHighlightMap = new Map<string, string>()
    for (const h of newHighlights) {
      for (const highlight of h.highlights) {
        newHighlightMap.set(highlight, h.id)
      }
    }
    
    // 找出需要删除的块（在现有中但不在新的中）
    const toDelete: BlockEntity[] = []
    const toKeep: string[] = []
    
    for (const [highlightText, { block }] of existingMap) {
      if (!newHighlightMap.has(highlightText)) {
        toDelete.push(block)
        console.log('Plugin Debug - Layer 2: Will delete:', highlightText, '(not in new highlights)')
      } else {
        toKeep.push(highlightText)
        console.log('Plugin Debug - Layer 2: Will keep unchanged:', highlightText, '(preserving user highlights)')
      }
    }
    
    // 删除不再需要的块
    for (const block of toDelete) {
      await logseq.Editor.removeBlock(block.uuid)
      console.log('Plugin Debug - Layer 2: Removed outdated highlight:', block.content)
    }
    
    // 只添加真正新的高亮（在新的中但不在现有中）
    const newBlocks: IBatchBlock[] = []
    for (const [highlightText, sourceId] of newHighlightMap) {
      if (!existingMap.has(highlightText)) {
        newBlocks.push({
          content: `${highlightText} [${logseq.settings!.highlightsRefChar}](${sourceId})`
        })
        console.log('Plugin Debug - Layer 2: Will add:', highlightText, '(new highlight)')
      }
    }
    
    // 批量插入新块
    if (newBlocks.length > 0) {
      await logseq.Editor.insertBatchBlock(
        layerTwoBlock.uuid,
        newBlocks,
        {
          before: false,
          sibling: false,
        }
      )
      console.log('Plugin Debug - Layer 2: Added new highlights:', newBlocks.length)
    }
    
    console.log('Plugin Debug - Layer 2: Incremental update completed. Deleted:', toDelete.length, 'Added:', newBlocks.length)
  } catch (error) {
    console.error('Error in incremental update Layer 2 children:', error)
  }
}

// 全局存储已注册的处理器，避免重复注册
let isRendererRegistered = false

export const createSecondCutBtn = () => {
  // 如果已经注册过全局处理器，就不再重复注册
  if (!isRendererRegistered) {
    isRendererRegistered = true
    console.log('Plugin Debug - Registering global macro renderer for secondCut')
    
    logseq.App.onMacroRendererSlotted(async ({ slot, payload }) => {
      const [type] = payload.arguments
      if (!type) return

      const id = type.split('_')[1]?.trim()
      const btnId = `secondCut_${id}`

      if (!type.startsWith(':secondCut_')) return

      console.log('Plugin Debug - Rendering secondCut button for slot:', slot, 'type:', type)

      logseq.provideModel({
        async secondCut() {
          console.log('Plugin Debug - secondCut button clicked')
          
          ///////////////////
          //// SECOND CUT ////
          ///////////////////
          const pageBT = await logseq.Editor.getCurrentPageBlocksTree()
          if (!pageBT || !pageBT[0]) return

          // 查找包含这个 renderer 的 Layer 1 块
          const findLayer1WithRenderer = (blocks: BlockEntity[]): BlockEntity | null => {
            for (const block of blocks) {
              if (block.content && block.content.includes(`{{renderer :secondCut_${id}}}`)) {
                return block
              }
              if (block.children && block.children.length > 0) {
                const found = findLayer1WithRenderer(block.children as BlockEntity[])
                if (found) return found
              }
            }
            return null
          }

          const layer1Block = findLayer1WithRenderer(pageBT)
          if (!layer1Block) {
            console.error('Plugin Debug - Could not find Layer 1 block with renderer:', id)
            return
          }

          const blockBT = await logseq.Editor.getBlock(layer1Block.uuid, {
            includeChildren: true,
          })
          if (!blockBT) return

          const blockBTChildren: BlockEntity[] = blockBT.children as BlockEntity[]
          const secondCutArr: { highlights: string[]; id: string }[] = []
          await recurseSecondCut(blockBTChildren, secondCutArr)

          // Filter out empty highlight arrays
          const validHighlights = secondCutArr.filter(item => item.highlights && item.highlights.length > 0)

          console.log('Plugin Debug - Second cut: Total blocks processed:', secondCutArr.length)
          console.log('Plugin Debug - Second cut: Valid highlights found:', validHighlights.length)

          if (validHighlights.length === 0) {
            const { preferredFormat } = await logseq.App.getUserConfigs()
            logseq.UI.showMsg(
              `No highlights found for second cut. 请确保您有高亮内容，并检查插件设置。当前格式: ${preferredFormat}, Layer 2 方法: ${logseq.settings!.layer2Highlights}`,
              'error',
            )
            return
          }

          // 查找现有的 Layer 2 块或创建新的
          let layerTwoBlock = await findExistingLayer2Block()
          
          if (layerTwoBlock) {
            // 如果找到现有的 Layer 2 块，进行增量更新
            console.log('Plugin Debug - Found existing Layer 2 block, performing incremental update...')
            
            // 更新 Layer 2 块的内容
            await logseq.Editor.updateBlock(
              layerTwoBlock.uuid,
              String(logseq.settings!.layer2)
            )
            
            // 进行增量更新子块
            await incrementalUpdateLayer2Children(layerTwoBlock, validHighlights)
          } else {
            // 如果没有找到现有的 Layer 2 块，创建新的
            console.log('Plugin Debug - No existing Layer 2 block found, creating new one...')
            
            // Layer 2 应该在 Layer 1 上面，所以我们需要在 Layer 1 之前插入
            layerTwoBlock = await logseq.Editor.insertBlock(
              layer1Block.uuid,
              String(logseq.settings!.layer2),
              {
                before: true,
                sibling: true,
              },
            )
            
            if (!layerTwoBlock) return

            // 创建初始的子块
            const highlightsBatchBlks: IBatchBlock[] = []
            for (const h of validHighlights) {
              if (h.highlights.length === 1) {
                const payload = {
                  content: `${h.highlights[0]} [${logseq.settings!.highlightsRefChar}](${h.id})`,
                }
                highlightsBatchBlks.push(payload)
              } else {
                for (const i of h.highlights) {
                  const payload = {
                    content: `${i} [${logseq.settings!.highlightsRefChar}](${h.id})`,
                  }
                  highlightsBatchBlks.push(payload)
                }
              }
            }

            await logseq.Editor.insertBatchBlock(
              layerTwoBlock.uuid,
              highlightsBatchBlks,
              {
                before: false,
                sibling: false,
              },
            )
          }
          
          if (!layerTwoBlock) return

          logseq.Editor.openInRightSidebar(layerTwoBlock.uuid)
        },
      })

      logseq.provideStyle(`
        .renderBtn {
          border: 1px solid black;
          border-radius: 8px;
          padding: 3px;
          font-size: 80%;
          background-color: white;
          color: black;
        }
        .renderBtn:hover {
          background-color: black;
          color: white;
        }
      `)

      logseq.provideUI({
        key: `${btnId}`,
        slot,
        reset: true,
        template: `<button data-on-click="secondCut" class="renderBtn">Extract Highlights</button>`,
      })
    })
  } else {
    console.log('Plugin Debug - Global macro renderer already registered, skipping')
  }
}