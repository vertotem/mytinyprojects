import '@logseq/libs'

import { BlockEntity } from '@logseq/libs/dist/LSPlugin.user'

import { settings } from './settings'
import { goSummarise } from './utils'

const main = async () => {
  console.log('logseq-psummarise-plugin loaded')
  
  // 检查Logseq版本并提供兼容性信息
  try {
    const info = await logseq.App.getInfo()
    console.log('Logseq version:', info.version)
    
    // 为用户显示插件加载信息
    if (info.version) {
      logseq.UI.showMsg(`Progressive Summarization插件已加载 (Logseq ${info.version})`, 'success')
    }
  } catch (error) {
    console.log('Could not get Logseq version info:', error)
  }

  // SUMMARISE BLOCK
  logseq.Editor.registerBlockContextMenuItem('Psummarise block', async (e) => {
    const arrBlk: BlockEntity[] = []
    const blk = await logseq.Editor.getBlock(e.uuid)
    if (!blk) return
    arrBlk.push(blk)
    goSummarise(arrBlk)
  })

  // SUMMARISE BLOCK AND CHILD BLOCKS
  logseq.Editor.registerBlockContextMenuItem(
    'Psummarise block and children',
    async (e) => {
      const arrBlk: BlockEntity[] = []
      const blk = await logseq.Editor.getBlock(e.uuid, {
        includeChildren: true,
      })
      if (!blk) return
      arrBlk.push(blk)
      goSummarise(arrBlk)
    },
  )

  // SUMMARISE PAGE
  logseq.provideModel({
    async extract() {
      const pageBT: BlockEntity[] =
        await logseq.Editor.getCurrentPageBlocksTree()
      if (!pageBT) {
        logseq.UI.showMsg(
          'This function is not available in the rolling journal page. It can only be used on a single journal or regular page',
          'error',
        )
        return
      }
      goSummarise(pageBT)
    },
  })

  logseq.App.registerUIItem('toolbar', {
    key: 'logseq-psummarise-plugin',
    template: `<a data-on-click="extract" class="button"><i class="ti ti-underline"></i></a>`,
  })

  // 添加测试高亮检测的上下文菜单项
  logseq.Editor.registerBlockContextMenuItem('测试高亮检测', async (e) => {
    const blk = await logseq.Editor.getBlock(e.uuid)
    if (!blk || !blk.content) {
      logseq.UI.showMsg('该块没有内容', 'warning')
      return
    }

    const { preferredFormat } = await logseq.App.getUserConfigs()
    
    // 测试粗体检测
    const rxMdBold = /\*\*([^*]+?)\*\*/g
    const rxOrgBold = /\*([^*]+?)\*/g
    const boldMatches = []
    const boldRegex = preferredFormat === 'markdown' ? rxMdBold : rxOrgBold
    let match
    while ((match = boldRegex.exec(blk.content)) !== null) {
      boldMatches.push(match[1])
    }

    // 测试高亮检测
    const rxMdHighlight = /==([^=]+?)==/g
    const rxOrgHighlight = /\^\^([^^]+?)\^\^/g
    const highlightMatches = []
    const highlightRegex = preferredFormat === 'markdown' ? rxMdHighlight : rxOrgHighlight
    highlightRegex.lastIndex = 0
    while ((match = highlightRegex.exec(blk.content)) !== null) {
      highlightMatches.push(match[1])
    }

    const message = `
块内容: ${blk.content}
格式: ${preferredFormat}
找到的粗体 (**Bold**): ${JSON.stringify(boldMatches)}
找到的高亮 (==Highlights==): ${JSON.stringify(highlightMatches)}
当前Layer 1设置: ${logseq.settings!.layer1Highlights}
    `.trim()

    logseq.UI.showMsg(message, 'info', { timeout: 10000 })
    console.log('高亮检测测试结果:', message)
  })
}

logseq.useSettingsSchema(settings).ready(main).catch(console.error)
